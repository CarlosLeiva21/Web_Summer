
interface Hability {
    _id: number,
    name: string,
    description: string,
};

export default Hability;